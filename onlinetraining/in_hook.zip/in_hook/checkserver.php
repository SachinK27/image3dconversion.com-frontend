<?
require_once (__DIR__.'/crest.php');

CRest::checkServer();